import React from 'react'
import { Link } from 'react-router-dom'
const ImageCard = ({url,id}) => {
  return (
    <div className='border 2xl'>
      <Link to={`/Details/${id}`}><img src={url} alt={id} /></Link>
       
    </div>
  )
}

export default ImageCard