import React from 'react'
import FetchApi from './FetchApi'

const photo = () => {
  return (
    <div>
        <FetchApi/>
    </div>
  )
}

export default photo