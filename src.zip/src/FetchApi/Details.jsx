import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
const Details = () => {
  const [state,setState] = useState([])
 const {id}= useParams;
  let showImage=async()=>{
    try{
    let x = await axios.get(`https://api.slingacademy.com/v1/sample-data/photos/${id}`)
    console.log(x.data)
    setState({
      url: x.data[0].url,
      id: x.data[0].id,
      title: x.data[0].title,
      description: x.data[0].description,
    })
    }catch{
      console.error("Error getting")
    }
   
  }
  useEffect(()=>{
    showImage();
  },[])
  return (
    <>
          <div>
            <Link to={`/`}>Back to Home</Link>
            </div> 
            <div key={id}>
              <h1>{state.id}</h1>
              <img src={state.url} alt={state.title} />
              <h1>{state.title}</h1>
              <h2>{state.description}</h2>

              </div> 

      </>
      

    



  )
}

export default Details