import React from 'react'
import CustomRoutes from "./routes/CustomRoute"
const App = () => {
  return (
    <div>
      <CustomRoutes/>
    </div>
  )
}

export default App